$(function() {
    $("li:nth-child(3)").removeClass('hot');

    $('li.hot').addClass('favorite')
});