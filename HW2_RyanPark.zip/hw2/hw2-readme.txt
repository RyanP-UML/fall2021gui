GitHub URL where the application resides:
https://ryanp-uml.github.io/fall2021gui/hw2/index.html

Link to the Github repository:
https://github.com/RyanP-UML/fall2021gui/tree/gh-pages/hw2